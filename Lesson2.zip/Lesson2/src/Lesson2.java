public class Lesson2 {
    public static void main(String[] args) {
        partOne();
        partTwo();
        partThree();
        partFour();
    }

    public static boolean partOne() {
        int a = 12;
        int b = 4;
        int c = a + b;
        return (10 <= c) && (c <= 20);
    }
    public static void partTwo(){
        int a = 4;
        if (a>=0)
            System.out.println("Число положительное");
        else
            System.out.println("Число отриацательное");
    }
    public static boolean partThree() {
        int a=5;
        return a < 0;
    }
    public static void partFour(){
        String name = "Имена";
        for (int i = 0; i < 6; i++  ) {
        System.out.println(name);
        }
    }
    public static boolean partFive(int year) {
      return (year%4==0 || year%400==0 && year%100!=0  );
    }
}


